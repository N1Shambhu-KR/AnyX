package com.a.anyx.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.a.anyx.R

class SendReceiveActivity:AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_send_receive)


    }
}